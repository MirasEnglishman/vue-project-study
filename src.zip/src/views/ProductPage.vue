<template>
  <div class="product-page">
    <h1>Список товаров</h1>
    
    <!-- Блок загрузки -->
    <div v-if="loading" class="loading">Загрузка...</div>
    
    <!-- Список товаров -->
    <div v-else class="product-list">
      <div
        class="product-card"
        v-for="product in products"
        :key="product.id"
        @click="showProductDetails(product)"
      >
        <!-- Главное (первое) изображение — если хотите показывать на карточке -->
        <img
          v-if="product.images && product.images.length"
          :src="product.images[0]"
          alt="Фото товара"
        />
        <h3>{{ product.name }}</h3>
        <p>{{ product.description }}</p>
        <p class="category">Категория: {{ product.category_name }}</p>
      </div>
    </div>
    
    <!-- Модальное окно для детального просмотра товара с слайдером -->
    <div
      class="product-modal"
      v-if="selectedProduct"
      @click.self="closeModal"
    >
      <div class="product-modal-content">
        <span class="close-btn" @click="closeModal">&times;</span>
        
        <h2>{{ selectedProduct.name }}</h2>
        
        <!-- СЛАЙДЕР ИЗОБРАЖЕНИЙ -->
        <div
          class="slider"
          v-if="selectedProduct.images && selectedProduct.images.length"
        >
          <button class="slider-arrow left" @click.stop="prevImage">&laquo;</button>
          <img
            class="slider-image"
            :src="selectedProduct.images[selectedImageIndex]"
            alt="Фото товара"
          />
          <button class="slider-arrow right" @click.stop="nextImage">&raquo;</button>
        </div>
        
        <p>{{ selectedProduct.description }}</p>
        <p>Категория: {{ selectedProduct.category_name }}</p>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  name: 'ProductPage',
  data() {
    return {
      products: [],
      categories: [],
      loading: true,
      selectedProduct: null,
      selectedImageIndex: 0,
    };
  },
  methods: {
    async fetchProducts() {
      try {
        // Запрос продуктов
        const productsResponse = await axios.get('http://127.0.0.1:8000/api/products');
        // Запрос категорий
        const categoriesResponse = await axios.get('http://127.0.0.1:8000/api/categories');
        
        // Сопоставление продуктов с их категориями
        this.categories = categoriesResponse.data;
        
        // Парсим images, превращая строку JSON в массив
        this.products = productsResponse.data.map(product => {
          let parsedImages = [];
          try {
            parsedImages = product.images ? JSON.parse(product.images) : [];
          } catch (err) {
            console.error('Ошибка парсинга поля images:', err);
          }

          return {
            ...product,
            images: parsedImages,
            category_name: this.categories.find(category => category.id === product.category_id)?.name || 'Неизвестно',
          };
        });

        this.loading = false;
      } catch (error) {
        console.error('Ошибка при загрузке товаров или категорий:', error);
        this.loading = false;
      }
    },
    showProductDetails(product) {
      // Открываем модальное окно с деталями выбранного товара
      this.selectedProduct = product;
      this.selectedImageIndex = 0; // Начинаем показ с первого изображения
    },
    closeModal() {
      // Закрываем модальное окно
      this.selectedProduct = null;
      this.selectedImageIndex = 0;
    },
    prevImage() {
      // Переключение на предыдущее изображение
      const total = this.selectedProduct.images.length;
      this.selectedImageIndex = (this.selectedImageIndex + total - 1) % total;
    },
    nextImage() {
      // Переключение на следующее изображение
      const total = this.selectedProduct.images.length;
      this.selectedImageIndex = (this.selectedImageIndex + 1) % total;
    },
  },
  created() {
    this.fetchProducts();
  },
};
</script>

<style scoped>
/* Общий стиль страницы */
.product-page {
  min-height: 100vh;
  background-color: #f5f5f5;
  padding: 30px 20px;
  text-align: center;
  font-family: Arial, sans-serif;
}

.product-page h1 {
  margin-bottom: 30px;
  color: #333;
}

.loading {
  font-size: 1.5em;
  color: #888;
}

/* Список товаров (Grid с максимум 4 колонками) */
.product-list {
  display: grid;
  /* Если нужно строго 4 колонки, используйте:
     grid-template-columns: repeat(4, 1fr);
     и медиазапросы для адаптации */
  grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
  gap: 20px;
  max-width: 1200px;
  margin: 0 auto;
  justify-items: center;
}

/* Карточка товара */
.product-card {
  width: 250px;
  border: 1px solid #ccc;
  border-radius: 8px;
  padding: 16px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  background-color: #fff;
  text-align: left;
  transition: transform 0.2s, box-shadow 0.2s;
  cursor: pointer;
}

.product-card:hover {
  transform: scale(1.03);
  box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
}

.product-card img {
  width: 100%;
  height: 150px;
  object-fit: cover;
  border-radius: 4px;
}

.product-card h3 {
  font-size: 1.2em;
  margin: 10px 0;
  color: #333;
}

.product-card p {
  margin: 5px 0;
  color: #555;
}

.product-card .category {
  font-size: 0.9em;
  color: #777;
  font-style: italic;
}

/* Модальное окно для детального просмотра */
.product-modal {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0,0,0,0.5); /* Затемнение фона */
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
}

.product-modal-content {
  background-color: #fff;
  position: relative;
  width: 80%;
  max-width: 600px;
  padding: 20px;
  border-radius: 10px;
  animation: showModal 0.3s ease;
}

/* Кнопка закрытия модального окна */
.close-btn {
  position: absolute;
  top: 15px;
  right: 20px;
  font-size: 2rem;
  font-weight: bold;
  color: #aaa;
  cursor: pointer;
}

.close-btn:hover {
  color: #333;
}

/* СЛАЙДЕР */
.slider {
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 20px;
}

.slider-arrow {
  cursor: pointer;
  background-color: #eee;
  border: none;
  font-size: 1.5rem;
  font-weight: bold;
  padding: 10px;
  transition: background-color 0.2s;
  user-select: none;
}

.slider-arrow:hover {
  background-color: #ddd;
}

.slider-image {
  max-width: 80%;
  max-height: 400px;
  border: 1px solid #ccc;
  border-radius: 4px;
  object-fit: cover;
}

/* Анимация появления модального окна */
@keyframes showModal {
  from {
    opacity: 0;
    transform: translateY(-30px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
</style>
